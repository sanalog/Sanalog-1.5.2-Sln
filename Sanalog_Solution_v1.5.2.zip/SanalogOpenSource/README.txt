﻿Sanalog v1.5



İndirmiş olduğunuz Sanalog İçerik Yönetim Sisteminin kurulumu için yapmanız gereken işlemler;

www.domainadresiniz.com/install adresine giriniz ve gerekli izinleri veriniz.

İzinler;
App_GlobalResources (Modify)
uploads (Modify)
Web.Config (Modify)

Hosting paneliniz yada IIS üzerinde izinleri veriniz.
Detay için ilgili makaleyi okuyabilirsiniz.
http://www.sanalog.org/tr/makale/sanalog-kolay-kurulum-sihirbazi.aspx

Aşamalar;

Adım 1. İzinlerini verin ve sözleşmeyi onaylayıp bir sonra ki adıma geçiniz.
Adım 2. Sunucunuz da Database yolunu belirtiniz(localhost), Veritabanı ismi (Açmış olduğunuz Veritabanı) - Kullanıcı Adı - 
Şifre yazınız. "Yeni Veritabanı Oluştur" kısımlarını seçiniz.
Adım 3. Yönetici panel bilgilerinizi giriniz. (Bu işlem Veritabanı dosyalarını oluşturur ve bilgilerinizi kaydeder. ) Unutmayınız Bekleme
Uyarılarına uyunuz sunucunuzun hızına göre bu işlem 1 ile 3 dk. arası sürebilir.
Adım 4. install dizinini siliniz ve sitenizi istediğiniz gibi kullanabilirsiniz.


SANALOG kullanımını öğrenmek için www.sanalog.org adresini takip edebilirsiniz.



http://www.sanalog.org/
https://twitter.com/SANALOGI
https://www.facebook.com/Sanalog
http://www.sanalog.org/tr/blog.aspx

Sanalog'a destek vermek için lütfen geri bildirimlerinizi bizlerle paylaşın.


* Bu yazılım GNU Genel Kamu Lisansı (GNU General Public License) versiyon 3.0 ve sonrası için geçerlidir.