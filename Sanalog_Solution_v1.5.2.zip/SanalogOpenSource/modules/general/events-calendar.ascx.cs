﻿using System.Data;
using System;
using System.Web.UI.HtmlControls;
using Snlg_DataBase;
using System.Text;
using System.Web.UI;
using System.Data.SqlClient;
using System.Globalization;
using System.Web.Script.Serialization;

public partial class modules__diger_etkinlik_takvimi_buyuk : Snlg_UserControlBaseClass
{
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }
}