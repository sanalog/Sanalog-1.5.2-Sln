﻿using System;

public partial class modules_diger_iletisim_formu : Snlg_UserControlBaseClass
{
    protected void Page_Load(object sender, System.EventArgs e)
    {
    }
}