﻿
public partial class modules_z_defteri_yorum_yaz : Snlg_UserControlBaseClass
{
}